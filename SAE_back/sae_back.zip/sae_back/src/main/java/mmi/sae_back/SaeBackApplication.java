package mmi.sae_back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaeBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaeBackApplication.class, args);
	}

}
