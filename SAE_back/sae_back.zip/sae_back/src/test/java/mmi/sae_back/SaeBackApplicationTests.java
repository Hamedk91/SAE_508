package mmi.sae_back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaeBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
