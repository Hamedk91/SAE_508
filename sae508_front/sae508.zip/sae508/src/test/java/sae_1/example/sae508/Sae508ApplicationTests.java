package sae_1.example.sae508;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sae508ApplicationTests {

	@Test
	void contextLoads() {
	}

}
