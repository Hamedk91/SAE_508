package sae_1.example.sae508;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sae508Application {

	public static void main(String[] args) {
		SpringApplication.run(Sae508Application.class, args);
	}

}
